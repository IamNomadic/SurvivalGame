using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BunnyWander : MonoBehaviour
{
    public GameObject PlayerCharacter;
    public SmellZone smellZone;
    public GameTimer GT;
    public Rigidbody2D rb;
    Vector2 direction;
    Vector2 zero = new Vector2(2,2);
    float distance;
    float speed;
    bool hit;
    bool targetLock;
    private void Awake()
    {
        PlayerCharacter = GameObject.FindGameObjectWithTag("Player");
        GT = GameObject.FindObjectOfType<GameTimer>();

    }
    private void Start()
    {
        
        GameTimer GT = GetComponent<GameTimer>();
        if (GT.CurrentDifficulty > 2)
        {
            this.transform.localScale = new Vector3(0.6f, 0.6f, 1);
        }
    }
    private void Update()
    {
        distance = ((float)Math.Sqrt((gameObject.transform.position.x  - PlayerCharacter.transform.position.x)*(gameObject.transform.position.x - PlayerCharacter.transform.position.x) + (gameObject.transform.position.y - PlayerCharacter.transform.position.y) * (gameObject.transform.position.y - PlayerCharacter.transform.position.y)));
        Vector2 direction = transform.position - PlayerCharacter.transform.position;
        direction.Normalize();
        
        
        #region Phase 1
        if (GT.CurrentDifficulty <= 0.8f)
        {
            if (distance > 0.9 &&!hit)
            {
                speed = 0.7f;
            }
            else if (distance < 0.9 && !hit)
            {
                speed = 1.5f;
            }
            if (smellZone.targetLock)
            {
                rb.velocity = direction * speed;
            }
            else if (!smellZone.targetLock)
            {
                rb.velocity = rb.velocity / zero;
            }
        }
        #endregion
        #region Phase 2
        else if (GT.CurrentDifficulty <1.8)
        {
            if (distance > 1.0 && !hit)
            {
                speed = 0.7f;
            }
            else if (distance > 0.4 && !hit)
            {
                speed = -0.5f;
            }
            else if (distance > 0.1 && !hit)
            {
                speed = -1.8f;
            }
            else if (distance < 0.1)
            {
                speed = 1.8f;
                hit = true;
                StartCoroutine(HitPlayer());
            }
            if (smellZone.targetLock)
            {
                rb.velocity = direction * speed;
            }
            else if (!smellZone.targetLock)
            {
                rb.velocity = rb.velocity / zero;
            }
        }
        #endregion
        #region Phase 3
        else if (GT.CurrentDifficulty <2.8)
        {
            if (distance > 1.4 && !hit)
            {
                speed = -0.5f;
            }
            else if (distance > 0.4 && !hit)
            {
                speed = -0.7f;
            }
            else if (distance > 0.1 && !hit)
            {
                speed = -1.8f;
            }
            else if (distance < 0.1)
            {
                speed = 1.8f;
                hit = true;
                StartCoroutine(HitPlayer());
            }
            if (smellZone.targetLock)
            {
                rb.velocity = direction * speed;
            }
            else if (!smellZone.targetLock)
            {
                rb.velocity = rb.velocity / zero;
            }
        }
        #endregion
        #region Phase 4
        else if (GT.CurrentDifficulty < 3.8)
        {
            rb.velocity = direction*-0.2f;
            if (distance > 1.4 && !hit)
            {
                speed = -0.7f;
            }
            else if (distance > 1 && !hit)
            {
                speed = -0.9f;
            }
            else if (distance > 0.4 && !hit)
            {
                speed = -1.3f;
            }
            else if (distance < 0.1 && !hit)
            {
                speed = -1.8f;
            }
            else if (distance < 0.1)
            {
                speed = 1.8f;
                hit = true;
                StartCoroutine(HitPlayer());
            }
            if (smellZone.targetLock)
            {
                rb.velocity = direction * speed;
            }
            else if (!smellZone.targetLock)
            {
                rb.velocity = rb.velocity / zero;
            }
        }
        #endregion
        IEnumerator HitPlayer()
        {
            yield return new WaitForSeconds(1);
            hit = false;
        }
    }
    
   
}
